<?
$dbaction=$_POST['dbaction'];

echo $dbaction;
?>